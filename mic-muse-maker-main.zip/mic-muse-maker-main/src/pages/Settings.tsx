import React from 'react';
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { 
  Settings as SettingsIcon, 
  Download, 
  Volume2, 
  Smartphone, 
  Wifi, 
  Bell,
  Moon,
  Sun,
  Database
} from "lucide-react";

const Settings = () => {
  const [volume, setVolume] = React.useState([75]);
  const [offlineMode, setOfflineMode] = React.useState(true);
  const [notifications, setNotifications] = React.useState(true);
  const [darkMode, setDarkMode] = React.useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-20 px-4 max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold flex items-center justify-center space-x-3">
            <SettingsIcon className="h-10 w-10 text-primary" />
            <span>Settings</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Customize your ChemLearn experience
          </p>
        </div>

        {/* App Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Smartphone className="h-5 w-5" />
              <span>App Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Moon className="h-4 w-4" />
                  <span className="font-medium">Dark Mode</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Switch to dark theme for better viewing in low light
                </p>
              </div>
              <Switch 
                checked={darkMode} 
                onCheckedChange={setDarkMode}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Bell className="h-4 w-4" />
                  <span className="font-medium">Notifications</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Get reminders for study sessions and new lessons
                </p>
              </div>
              <Switch 
                checked={notifications} 
                onCheckedChange={setNotifications}
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Volume2 className="h-4 w-4" />
                <span className="font-medium">Sound Volume</span>
              </div>
              <div className="px-4">
                <Slider
                  value={volume}
                  onValueChange={setVolume}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>0%</span>
                  <span>{volume[0]}%</span>
                  <span>100%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Offline Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Download className="h-5 w-5" />
              <span>Offline Learning</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Wifi className="h-4 w-4" />
                  <span className="font-medium">Offline Mode</span>
                  <Badge variant="secondary">Enabled</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Access lessons without internet connection
                </p>
              </div>
              <Switch 
                checked={offlineMode} 
                onCheckedChange={setOfflineMode}
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Database className="h-4 w-4" />
                <span className="font-medium">Downloaded Content</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Electrochemistry Basics</span>
                  <Badge variant="outline">Downloaded</Badge>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Atomic Structure</span>
                  <Button variant="ghost" size="sm">Download</Button>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Thermodynamics</span>
                  <Button variant="ghost" size="sm">Download</Button>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Total offline storage: 45.2 MB
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Learning Preferences */}
        <Card>
          <CardHeader>
            <CardTitle>Learning Preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4 border-2 border-primary bg-primary/5">
                <div className="text-center">
                  <div className="text-lg font-semibold">Visual Learner</div>
                  <div className="text-sm text-muted-foreground">
                    Focus on diagrams and animations
                  </div>
                </div>
              </Card>
              <Card className="p-4 border">
                <div className="text-center">
                  <div className="text-lg font-semibold">Text-based</div>
                  <div className="text-sm text-muted-foreground">
                    Focus on equations and text
                  </div>
                </div>
              </Card>
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card>
          <CardHeader>
            <CardTitle>About ChemLearn</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Version:</span> 1.0.0
              </div>
              <div>
                <span className="font-medium">Build:</span> 2024.12.27
              </div>
              <div>
                <span className="font-medium">Platform:</span> Web/Mobile
              </div>
              <div>
                <span className="font-medium">Offline:</span> Ready
              </div>
            </div>
            
            <div className="pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                ChemLearn makes physical chemistry accessible through interactive learning. 
                Study anywhere, anytime with our offline-capable platform.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Settings;