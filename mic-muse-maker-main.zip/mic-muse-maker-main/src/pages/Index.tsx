import React from 'react';
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Play, Zap, Download, Users, Award } from "lucide-react";
import { useNavigate } from 'react-router-dom';

const Index = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Zap,
      title: "Interactive Animations",
      description: "Watch molecules and electrons move in real-time simulations"
    },
    {
      icon: Download,
      title: "Offline Learning",
      description: "Study anywhere without internet connection"
    },
    {
      icon: BookOpen,
      title: "Progressive Lessons",
      description: "Learn from basics to advanced topics step by step"
    },
    {
      icon: Users,
      title: "Visual Learning",
      description: "Complex chemistry made simple with diagrams and animations"
    }
  ];

  const recentLessons = [
    {
      title: "Electrochemistry Basics",
      progress: 0,
      difficulty: "Beginner",
      duration: "15 min"
    },
    {
      title: "Atomic Structure",
      progress: 0,
      difficulty: "Beginner", 
      duration: "20 min"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-20 px-4 text-center space-y-8 max-w-4xl mx-auto">
        <div className="space-y-4">
          <Badge className="px-4 py-2 text-sm">
            Interactive Chemistry Education
          </Badge>
          
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            ChemLearn
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
            Master physical chemistry through interactive lessons, animated diagrams, and real-time simulations. 
            Learn electrochemistry, thermodynamics, and more!
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Button 
            size="lg" 
            onClick={() => navigate('/lessons')}
            className="bg-gradient-to-r from-primary to-accent hover:shadow-glow-primary transition-all duration-300"
          >
            <Play className="mr-2 h-5 w-5" />
            Start Learning
          </Button>
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate('/lessons/electrochemistry')}
          >
            Try Demo Lesson
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-8">
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">5+</div>
            <div className="text-sm text-muted-foreground">Interactive Lessons</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">100%</div>
            <div className="text-sm text-muted-foreground">Offline Ready</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">∞</div>
            <div className="text-sm text-muted-foreground">Practice Problems</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">24/7</div>
            <div className="text-sm text-muted-foreground">Study Anytime</div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose ChemLearn?</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <feature.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Lessons */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">Get Started</h2>
            <Button variant="outline" onClick={() => navigate('/lessons')}>
              View All Lessons
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {recentLessons.map((lesson, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{lesson.title}</CardTitle>
                    <Badge variant="secondary">{lesson.difficulty}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Progress</span>
                      <span>{lesson.duration}</span>
                    </div>
                    <Progress value={lesson.progress} className="w-full" />
                    <Button 
                      className="w-full"
                      onClick={() => navigate('/lessons/electrochemistry')}
                    >
                      <Play className="mr-2 h-4 w-4" />
                      Start Lesson
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <Award className="h-16 w-16 text-primary mx-auto" />
          <h2 className="text-3xl font-bold">Ready to Master Chemistry?</h2>
          <p className="text-lg text-muted-foreground">
            Join thousands of students learning chemistry through interactive simulations and engaging content.
          </p>
          <Button 
            size="lg"
            onClick={() => navigate('/lessons')}
            className="bg-gradient-to-r from-primary to-accent hover:shadow-glow-primary transition-all duration-300"
          >
            Start Your Journey
          </Button>
        </div>
      </section>
    </div>
  );
};

export default Index;