import React from 'react';
import { Navigation } from "@/components/Navigation";
import { LessonCard } from "@/components/LessonCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Trophy, Clock, Target } from "lucide-react";
import { useNavigate } from 'react-router-dom';

const Lessons = () => {
  const navigate = useNavigate();

  const lessons = [
    {
      id: 'electrochemistry',
      title: 'Electrochemistry Basics',
      description: 'Learn about electrochemical cells, redox reactions, and electron flow with interactive animations.',
      duration: '15 min',
      difficulty: 'Beginner' as const,
      isCompleted: false
    },
    {
      id: 'atomic-structure',
      title: 'Atomic Structure',
      description: 'Explore the components of atoms, electron shells, and chemical bonding fundamentals.',
      duration: '20 min',
      difficulty: 'Beginner' as const,
      isCompleted: false
    },
    {
      id: 'thermodynamics',
      title: 'Chemical Thermodynamics',
      description: 'Understand enthalpy, entropy, and Gibbs free energy in chemical reactions.',
      duration: '25 min',
      difficulty: 'Intermediate' as const,
      isCompleted: false
    },
    {
      id: 'kinetics',
      title: 'Reaction Kinetics',
      description: 'Study reaction rates, activation energy, and catalysis mechanisms.',
      duration: '30 min',
      difficulty: 'Intermediate' as const,
      isCompleted: false
    },
    {
      id: 'quantum-chemistry',
      title: 'Quantum Chemistry',
      description: 'Dive into molecular orbitals, quantum mechanics, and advanced bonding theories.',
      duration: '35 min',
      difficulty: 'Advanced' as const,
      isCompleted: false
    }
  ];

  const stats = [
    { icon: BookOpen, label: 'Total Lessons', value: '5' },
    { icon: Clock, label: 'Study Time', value: '2.1h' },
    { icon: Trophy, label: 'Completed', value: '0/5' },
    { icon: Target, label: 'Progress', value: '0%' }
  ];

  const handleStartLesson = (lessonId: string) => {
    if (lessonId === 'electrochemistry') {
      navigate('/lessons/electrochemistry');
    } else {
      // For now, other lessons redirect to electrochemistry as a demo
      navigate('/lessons/electrochemistry');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-20 px-4 max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            ChemLearn Lessons
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Master physical chemistry through interactive lessons and animated diagrams
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-4 text-center">
                <stat.icon className="h-8 w-8 text-primary mx-auto mb-2" />
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Overall progress */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Trophy className="h-5 w-5 text-primary" />
              <span>Your Progress</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Course Completion</span>
                <span>0%</span>
              </div>
              <Progress value={0} className="w-full" />
              <p className="text-sm text-muted-foreground">
                Complete lessons to unlock advanced topics and earn achievements
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Lessons grid */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">Available Lessons</h2>
          
          <div className="grid gap-6">
            {lessons.map((lesson) => (
              <LessonCard
                key={lesson.id}
                title={lesson.title}
                description={lesson.description}
                duration={lesson.duration}
                difficulty={lesson.difficulty}
                isCompleted={lesson.isCompleted}
                onStart={() => handleStartLesson(lesson.id)}
              />
            ))}
          </div>
        </div>

        {/* Study tips */}
        <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-primary/20">
          <CardHeader>
            <CardTitle className="text-primary">Study Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Watch the animations carefully to understand molecular movements</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Practice writing chemical equations after each lesson</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Use the offline mode to study anywhere, anytime</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Review completed lessons to reinforce your understanding</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Lessons;