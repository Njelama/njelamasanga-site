import React, { useState } from 'react';
import { ElectrochemicalCell } from "@/components/ElectrochemicalCell";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, CheckCircle, BookOpen } from "lucide-react";

const ElectrochemistryLesson = () => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  
  const lessonSteps = [
    {
      title: "Introduction to Electrochemical Cells",
      content: "An electrochemical cell converts chemical energy into electrical energy through redox reactions."
    },
    {
      title: "Understanding Electrodes",
      content: "The anode is where oxidation occurs (electrons are lost), and the cathode is where reduction occurs (electrons are gained)."
    },
    {
      title: "Electron Flow",
      content: "Electrons flow from the anode to the cathode through the external circuit, creating an electric current."
    },
    {
      title: "Ion Movement",
      content: "In the solution, cations move toward the cathode and anions move toward the anode to maintain electrical neutrality."
    }
  ];

  const handleToggleAnimation = () => {
    setIsAnimating(!isAnimating);
  };

  const handleReset = () => {
    setIsAnimating(false);
  };

  const nextStep = () => {
    if (currentStep < lessonSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navigation />
      
      <div className="pt-20 px-4 max-w-6xl mx-auto space-y-6">
        {/* Lesson header */}
        <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <BookOpen className="h-8 w-8 text-primary" />
              <div>
                <CardTitle className="text-2xl">Electrochemistry Basics</CardTitle>
                <p className="text-muted-foreground">Learn how electrochemical cells work</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">
                Step {currentStep + 1} of {lessonSteps.length}
              </span>
              <div className="flex items-center space-x-2">
                <Progress value={(currentStep + 1) / lessonSteps.length * 100} className="w-32" />
                <span className="text-sm font-medium">
                  {Math.round((currentStep + 1) / lessonSteps.length * 100)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current lesson step */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm">
                {currentStep + 1}
              </span>
              <span>{lessonSteps[currentStep].title}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg leading-relaxed mb-4">
              {lessonSteps[currentStep].content}
            </p>
            <div className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={prevStep}
                disabled={currentStep === 0}
              >
                Previous
              </Button>
              <Button 
                onClick={nextStep}
                disabled={currentStep === lessonSteps.length - 1}
                className="flex items-center space-x-2"
              >
                <span>Next</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Interactive diagram */}
        <ElectrochemicalCell 
          isAnimating={isAnimating}
          onToggleAnimation={handleToggleAnimation}
          onReset={handleReset}
        />

        {/* Key concepts */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-blue-700 flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>Remember</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm space-y-1">
                <li>• Anode = Oxidation (electrons lost)</li>
                <li>• Cathode = Reduction (electrons gained)</li>
                <li>• Electrons flow through external circuit</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-green-700 flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>Equation</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-mono text-sm">E°cell = E°cathode - E°anode</p>
              <p className="text-xs text-muted-foreground mt-1">
                Standard cell potential calculation
              </p>
            </CardContent>
          </Card>

          <Card className="bg-purple-50 border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700 flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>Applications</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm space-y-1">
                <li>• Batteries and fuel cells</li>
                <li>• Electroplating</li>
                <li>• Corrosion prevention</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ElectrochemistryLesson;