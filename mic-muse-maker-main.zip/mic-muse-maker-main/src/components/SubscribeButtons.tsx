import React from 'react';
import { Button } from "@/components/ui/button";

const platforms = [
  { name: 'Spotify', color: 'bg-[#1DB954] hover:bg-[#1ed760]', icon: '♪' },
  { name: 'Apple Podcasts', color: 'bg-[#A855F7] hover:bg-[#9333EA]', icon: '🎧' },
  { name: 'Google Podcasts', color: 'bg-[#4285F4] hover:bg-[#3367D6]', icon: 'G' },
  { name: 'RSS Feed', color: 'bg-accent hover:bg-accent/90', icon: '📡' }
];

export const SubscribeButtons = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {platforms.map((platform) => (
        <Button
          key={platform.name}
          className={`${platform.color} text-white font-medium h-12 transition-all duration-300 hover:shadow-lg`}
          onClick={() => console.log(`Subscribe to ${platform.name}`)}
        >
          <span className="mr-2 text-lg">{platform.icon}</span>
          {platform.name}
        </Button>
      ))}
    </div>
  );
};