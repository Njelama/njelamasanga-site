import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Calendar, Clock } from "lucide-react";

interface EpisodeCardProps {
  title: string;
  description: string;
  date: string;
  duration: string;
  coverImage?: string;
  onPlay?: () => void;
}

export const EpisodeCard = ({ 
  title, 
  description, 
  date, 
  duration, 
  coverImage,
  onPlay 
}: EpisodeCardProps) => {
  return (
    <Card className="bg-card border-border hover:border-primary/50 transition-all duration-300 hover:shadow-glow-accent group">
      <CardContent className="p-6">
        <div className="flex space-x-4">
          <div className="relative flex-shrink-0">
            <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg flex items-center justify-center">
              {coverImage ? (
                <img src={coverImage} alt={title} className="w-full h-full object-cover rounded-lg" />
              ) : (
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded opacity-60" />
              )}
            </div>
            <Button
              onClick={onPlay}
              size="sm"
              className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full bg-primary hover:bg-primary/90 hover:shadow-glow-primary transition-all duration-300 opacity-0 group-hover:opacity-100"
            >
              <Play className="h-3 w-3 ml-0.5" />
            </Button>
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-card-foreground mb-2 line-clamp-2">{title}</h3>
            <p className="text-sm text-muted-foreground mb-3 line-clamp-3">{description}</p>
            
            <div className="flex items-center space-x-4 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Calendar className="h-3 w-3" />
                <span>{date}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="h-3 w-3" />
                <span>{duration}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};