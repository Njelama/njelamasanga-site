import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Play, Pause, RotateCcw } from "lucide-react";

interface ElectrochemicalCellProps {
  isAnimating: boolean;
  onToggleAnimation: () => void;
  onReset: () => void;
}

export const ElectrochemicalCell = ({ isAnimating, onToggleAnimation, onReset }: ElectrochemicalCellProps) => {
  const [electronPosition, setElectronPosition] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAnimating) {
      interval = setInterval(() => {
        setElectronPosition(prev => (prev + 1) % 100);
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isAnimating]);

  const resetAnimation = () => {
    setElectronPosition(0);
    onReset();
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center text-2xl">Electrochemical Cell</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Control buttons */}
          <div className="flex justify-center space-x-4">
            <Button onClick={onToggleAnimation} className="flex items-center space-x-2">
              {isAnimating ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              <span>{isAnimating ? 'Pause' : 'Start'} Animation</span>
            </Button>
            <Button variant="outline" onClick={resetAnimation} className="flex items-center space-x-2">
              <RotateCcw className="h-4 w-4" />
              <span>Reset</span>
            </Button>
          </div>

          {/* Cell diagram */}
          <div className="relative bg-gradient-to-b from-blue-50 to-blue-100 p-8 rounded-xl border">
            <svg width="100%" height="300" viewBox="0 0 800 300" className="mx-auto">
              {/* Electrolyte solution background */}
              <rect x="50" y="50" width="700" height="200" fill="#e0f2fe" rx="10" opacity="0.7" />
              
              {/* Anode (left electrode) */}
              <rect x="100" y="80" width="20" height="140" fill="hsl(var(--anode-copper))" />
              <text x="90" y="70" textAnchor="middle" className="text-sm font-semibold">Anode</text>
              <text x="90" y="260" textAnchor="middle" className="text-xs">Cu</text>
              
              {/* Cathode (right electrode) */}
              <rect x="680" y="80" width="20" height="140" fill="hsl(var(--cathode-silver))" />
              <text x="710" y="70" textAnchor="middle" className="text-sm font-semibold">Cathode</text>
              <text x="710" y="260" textAnchor="middle" className="text-xs">Ag</text>
              
              {/* Salt bridge */}
              <rect x="380" y="40" width="40" height="220" fill="#94a3b8" rx="20" />
              <text x="400" y="30" textAnchor="middle" className="text-xs font-medium">Salt Bridge</text>
              
              {/* External circuit wire */}
              <path d="M 120 80 Q 400 20 680 80" stroke="#374151" strokeWidth="4" fill="none" />
              
              {/* Electron flow animation */}
              {isAnimating && (
                <>
                  <circle 
                    cx={120 + (560 * electronPosition / 100)} 
                    cy={80 - 60 * Math.sin((electronPosition / 100) * Math.PI)}
                    r="4" 
                    fill="hsl(var(--electron-blue))"
                    className="animate-pulse"
                  />
                  <circle 
                    cx={120 + (560 * ((electronPosition + 25) % 100) / 100)} 
                    cy={80 - 60 * Math.sin((((electronPosition + 25) % 100) / 100) * Math.PI)}
                    r="4" 
                    fill="hsl(var(--electron-blue))"
                    className="animate-pulse"
                  />
                </>
              )}
              
              {/* Electron flow direction arrow */}
              <defs>
                <marker id="arrowhead" markerWidth="10" markerHeight="7" 
                        refX="9" refY="3.5" orient="auto">
                  <polygon points="0 0, 10 3.5, 0 7" fill="hsl(var(--electron-blue))" />
                </marker>
              </defs>
              <path d="M 200 50 L 250 50" stroke="hsl(var(--electron-blue))" strokeWidth="2" 
                    markerEnd="url(#arrowhead)" />
              <text x="225" y="45" textAnchor="middle" className="text-xs text-blue-600">e⁻ flow</text>
              
              {/* Ion movements in solution */}
              {isAnimating && (
                <>
                  {/* Cations moving to cathode */}
                  <circle cx={200 + (400 * electronPosition / 100)} cy="150" r="3" fill="hsl(var(--proton-red))" />
                  <text x="350" y="140" textAnchor="middle" className="text-xs text-red-600">Cu²⁺ →</text>
                  
                  {/* Anions moving to anode */}
                  <circle cx={600 - (400 * electronPosition / 100)} cy="180" r="3" fill="#10b981" />
                  <text x="450" y="200" textAnchor="middle" className="text-xs text-green-600">← NO₃⁻</text>
                </>
              )}
              
              {/* Labels */}
              <text x="200" y="280" textAnchor="middle" className="text-sm">CuSO₄ solution</text>
              <text x="600" y="280" textAnchor="middle" className="text-sm">AgNO₃ solution</text>
            </svg>
          </div>

          {/* Progress indicator */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Reaction Progress</span>
              <span>{Math.round(electronPosition)}%</span>
            </div>
            <Progress value={electronPosition} className="w-full" />
          </div>

          {/* Chemical equations */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="bg-red-50 border-red-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-red-700">Anode (Oxidation)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="font-mono text-sm">Cu(s) → Cu²⁺(aq) + 2e⁻</p>
                  <p className="text-xs text-muted-foreground">
                    Copper loses electrons and dissolves
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-blue-700">Cathode (Reduction)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="font-mono text-sm">Ag⁺(aq) + e⁻ → Ag(s)</p>
                  <p className="text-xs text-muted-foreground">
                    Silver ions gain electrons and deposit
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Overall reaction */}
          <Card className="bg-gradient-to-r from-blue-50 to-red-50 border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-center">Overall Cell Reaction</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-mono text-center text-lg">
                Cu(s) + 2Ag⁺(aq) → Cu²⁺(aq) + 2Ag(s)
              </p>
              <p className="text-center text-sm text-muted-foreground mt-2">
                Cell potential: E° = +0.46 V
              </p>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  );
};