import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Play, CheckCircle } from "lucide-react";

interface LessonCardProps {
  title: string;
  description: string;
  duration: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  isCompleted?: boolean;
  onStart: () => void;
}

export const LessonCard = ({ 
  title, 
  description, 
  duration, 
  difficulty, 
  isCompleted = false,
  onStart 
}: LessonCardProps) => {
  const difficultyColors = {
    Beginner: 'bg-green-100 text-green-800 border-green-200',
    Intermediate: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    Advanced: 'bg-red-100 text-red-800 border-red-200'
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-300 hover:border-primary/50">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">{title}</CardTitle>
          </div>
          {isCompleted && <CheckCircle className="h-5 w-5 text-green-600" />}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-muted-foreground">{description}</p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Badge className={difficultyColors[difficulty]}>
                {difficulty}
              </Badge>
              <span className="text-sm text-muted-foreground">{duration}</span>
            </div>
            
            <Button onClick={onStart} className="flex items-center space-x-2">
              <Play className="h-4 w-4" />
              <span>{isCompleted ? 'Review' : 'Start'}</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};