import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Home, BookOpen, Settings, Download } from "lucide-react";
import { useNavigate, useLocation } from 'react-router-dom';

export const Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: BookOpen, label: 'Lessons', path: '/lessons' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <Card className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 w-fit">
      <CardContent className="p-2">
        <div className="flex items-center space-x-2">
          {location.pathname !== '/' && (
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate(-1)}
              className="flex items-center space-x-1"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
          )}
          
          {navItems.map((item) => (
            <Button
              key={item.path}
              variant={isActive(item.path) ? "default" : "ghost"}
              size="sm"
              onClick={() => navigate(item.path)}
              className="flex items-center space-x-1"
            >
              <item.icon className="h-4 w-4" />
              <span className="hidden md:inline">{item.label}</span>
            </Button>
          ))}

          <div className="w-px h-6 bg-border mx-2" />
          
          <Button variant="ghost" size="sm" className="flex items-center space-x-1">
            <Download className="h-4 w-4" />
            <span className="hidden md:inline">Offline</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};